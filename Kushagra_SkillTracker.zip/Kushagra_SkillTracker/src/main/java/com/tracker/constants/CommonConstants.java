package com.tracker.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class CommonConstants.
 */
public class CommonConstants {
	
	/** The Constant SUCCESS_STRING. */
	public static final String SUCCESS_STRING = "Success";

}
