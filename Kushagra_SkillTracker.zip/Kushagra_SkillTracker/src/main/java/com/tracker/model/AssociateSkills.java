package com.tracker.model;

import java.io.Serializable;

public class AssociateSkills implements Serializable{

	private static final long serialVersionUID = 1L;

	int associateId;
	
	int skillId;
	
	
	
}
